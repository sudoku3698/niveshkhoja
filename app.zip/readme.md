Installation Process

Step 1 :- 
   run command git clone https://github.com/sudoku3698/niveshkhoja.git

Step 2 :- 
   Rename .env.example to .env
 
Step 3 :- 
   run command php artisan key:generate

Step 4 :-
   upload mysql file to your database from database/sudokvc4_niveshkhoja2018_06_24.sql

Step 5 :- 
   update .env file as per your configuration.
