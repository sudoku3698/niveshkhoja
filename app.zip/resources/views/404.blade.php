@extends('layouts.master')
@section('content')
<div class="content">

<div class="row">
<div class="col-lg-12">
<div class="error-container">
    <i class="pe-7s-way text-success big-icon"></i>
    <h1>404</h1>
    <strong>Page Not Found</strong>
    <p>
        Sorry, but the page you are looking for has note been found. Try checking the URL for error, then hit the refresh button on your browser or try found something else in our app.

    </p>
    
</div>






 
</div>
</div>
</div>
</div>
    @stop
@section('javascript')

@stop