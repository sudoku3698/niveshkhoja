<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Loan extends Model
{
  protected $table="loan_details";
}