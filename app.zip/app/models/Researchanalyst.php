<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Researchanalyst extends Model
{
  protected $table="research_analyst_details";
}