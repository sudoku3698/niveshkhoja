<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Bankdetails extends Model
{
  protected $table="bank_details";
}