<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Cfadetails extends Model
{
  protected $table="cfa_details";
}