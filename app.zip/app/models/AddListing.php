<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class AddListing extends Model
{
    protected $table="add_listing";
}
