<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class SendSms extends Model
{
  protected $table="send_sms";
}