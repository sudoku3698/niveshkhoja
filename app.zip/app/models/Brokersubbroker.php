<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Brokersubbroker extends Model
{
  protected $table="broker_subbroker";
}