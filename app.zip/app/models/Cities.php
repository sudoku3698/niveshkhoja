<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Cities extends Model
{
  protected $table="cities";
}