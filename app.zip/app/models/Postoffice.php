<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Postoffice extends Model
{
  protected $table="post_office_details";
}