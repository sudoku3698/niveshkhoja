<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Investmentadvisors extends Model
{
  protected $table="investment_advisors_details";
}