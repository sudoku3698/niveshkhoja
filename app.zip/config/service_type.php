<?php

return [
    'service_types'=>[
        'bank_details'=>'Bank Details',
        'broker_subbroker'=>'Broker Subbroker',
        'cfa_details'=>'CFA Details',
        'insurance_details'=>'Insurance Details',
        'investment_advisors_details'=>'Investment Advisors Details',
        'loan_details'=>'Loan Details',
        'mutual_fund_distributor'=>'Mutual Fund Distributor',
        'post_office_details'=>'Post Office Details',
        'research_analyst_details'=>'Research Analyst Details'
    ]
];
