<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-body">
                <?php if(Session('success')): ?>
                    <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.success('Succesfully Saved');
                    });
                    </script>


                    <div class="alert alert-success">

                    <?php echo e(Session('success')); ?>


                    </div>

                <?php endif; ?>
                <?php if(Session('error')): ?>
                    <script type="text/javascript">
                            $(document).ready(function () {

                                toastr.error('Something Went Wrong, Please try Again.');
                            });
                    </script>
                    <div class="alert alert-danger">
                    <?php echo e(Session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                <script type="text/javascript">
                        $(document).ready(function () {

                            toastr.error('Something Went Wrong, Please try Again.');
                        });
                </script>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <table id="example2" class="table table-striped table-bordered table-hover">
                    <thead>
                     <tr>
                        <th>Id</th>

                        <th>Name</th>

                        <th>Listing Title</th>

                        <th>Phone</th>

                        <th>Email</th>

                        <th>Address</th>

                        <th>City</th>

                        <th>Service Type</th>
                     </tr>

                    </thead>

                     <tbody>

                     <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td><?php echo e($listing->id); ?></td>

                            <td><?php echo e($listing->first_name); ?> <?php echo e($listing->last_name); ?></td>

                            <td><?php echo e($listing->listing_title); ?></td>

                            <td><?php echo e($listing->phone); ?></td>

                            <td><?php echo e($listing->email); ?></td>

                            <td><?php echo e($listing->address); ?></td>

                            <td><?php echo e($listing->city); ?></td>

                            <td><?php echo e($listing->service_type); ?></td>

                           </tr> 

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
                </div>
            </div>
        </div>    
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>