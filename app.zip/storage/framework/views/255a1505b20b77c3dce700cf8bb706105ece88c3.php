<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <div class="panel-body">
                <a class="small-header-action" href="">
                    <div class="clip-header">
                        <i class="fa fa-arrow-up"></i>
                    </div>
                </a>

                <div id="hbreadcrumb" class="pull-right m-t-lg">
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="index.html">Dashboard</a></li>
                        <li>
                            <span>Tables</span>
                        </li>
                        <li class="active">
                            <span> Broker Subbroker Details</span>
                        </li>
                    </ol>
                </div>
                <h2 class="font-light m-b-xs">
                    Broker Subbroker Details
                </h2>
                <!-- <small>Advanced interaction controls to any HTML table</small> -->
            </div>
                <div class="panel-heading">
                   
 


       
                <div class="panel-body">
                
                    <table id="example2" class="table table-striped table-bordered table-hover">
                    

                    <thead>
                     <tr>
                        <th>MUTUAL_FUND_DISTRIBUTOR_SUBCATEGORY</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_CONTACT</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_ADDRESS</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_CONTACT_PERSON</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_AMFI_REGISTRATION_NUMBER</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_ARN_VALIDITY</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_KYD</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_EUIN</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_EMAIL_ID</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_WEBSITE </th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_SERVICES_OFFERED</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_ABOUT</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_YEAR_ESTABLISH</th>
                        <th>MUTUAL_FUND_DISTRIBUTOR_REVIEW</th>
                        
                     </tr>
                    </thead>
                     <tbody>
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                   
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_SUBCATEGORY); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_CONTACT); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_ADDRESS); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_CONTACT_PERSON); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_AMFI_REGISTRATION_NUMBER); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_ARN_VALIDITY); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_KYD); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_EUIN); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_EMAIL_ID); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_WEBSITE); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_SERVICES_OFFERED); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_ABOUT); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_YEAR_ESTABLISH); ?></td>
                    <td><?php echo e($datas->MUTUAL_FUND_DISTRIBUTOR_REVIEW); ?></td>
                    
                    
                         
                 </tr> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     






        </tbody>
                </table>
                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>