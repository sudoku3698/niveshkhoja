<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                   Research Analyst
 


       
                <div class="panel-body">
        <form role="form"  method="post" action="<?php echo e(url('updatepostresearch_analyst')); ?>">
<input type="text" name="id"  value="<?php echo e($data->id); ?>" hidden="">
                        <div class="form-group">
                        <label>Choose Research Analyst Category</label>
                        <select class="form-control" style="width: 100%" name="Research_Analyst_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="901" <?php echo e($data->RESEARCH_ANALYST_SUBCATEGORY == 901 ? "selected":""); ?>>Demo1</option>
                            <option value="902" <?php echo e($data->RESEARCH_ANALYST_SUBCATEGORY == 902 ? "selected":""); ?>>Demo2</option>
                        </select>
                        </div>

                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact"  value="<?php echo e($data->RESEARCH_ANALYST_CONTACT); ?>" class="form-control" name="Research_Analyst_Contact">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" value="<?php echo e($data->RESEARCH_ANALYST_ADDRESS); ?>" class="form-control" name="Research_Analyst_Address">
                        </div>

                        <div class="form-group">
                        <label>Contact Person</label> 
                        <input type="text" placeholder="Enter Contact Person"  value="<?php echo e($data->RESEARCH_ANALYST_CONTACT_PERSON); ?>" class="form-control" name="Research_Analyst_Contact_Person">
                        </div>

                        <div class="form-group">
                        <label>Insurer</label> 
                        <input type="text" placeholder="Enter Insurer"  value="<?php echo e($data->RESEARCH_ANALYST_INSURER); ?>" class="form-control" name="Research_Analyst_Insurer">
                        </div>

                        <div class="form-group">
                        <label>Registration Number</label> 
                        <input type="text" placeholder="Enter Registration Number" value="<?php echo e($data->RESEARCH_ANALYST_REGISTRATION_NUMBER); ?>" class="form-control" name="Research_Analyst_Registration_Number">
                        </div>

                        <div class="form-group">
                        <label>Category</label> 
                        <input type="text" placeholder="Enter Category" value="<?php echo e($data->RESEARCH_ANALYST_CATEGORY); ?>" class="form-control" name="Research_Analyst_Category">
                        </div>


                        <div class="form-group">
                        <label>Registration Valid Upto</label> 
                        <input type="text" placeholder="Enter Registration Valid Upto" value="<?php echo e($data->RESEARCH_ANALYST_REGISTRATION_VALID_UPTO); ?>" class="form-control" name="Research_Analyst_Registration_Valid_Upto">
                        </div>

                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" value="<?php echo e($data->RESEARCH_ANALYST_EMAIL_ID); ?>" class="form-control" name="Research_Analyst_Email_ID">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website"  value="<?php echo e($data->RESEARCH_ANALYST_WEBSITE); ?>" class="form-control" name="Research_Analyst_Website">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" value="<?php echo e($data->RESEARCH_ANALYST_SERVICES_OFFERED); ?>" class="form-control" name="Research_Analyst_Services_Offered">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" value="<?php echo e($data->RESEARCH_ANALYST_ABOUT); ?>"  class="form-control" name="Research_Analyst_About">
                        </div>


                        <div class="form-group">
                        <label>Year Established</label> 
                        <input type="text" placeholder="Enter Year Established" value="<?php echo e($data->RESEARCH_ANALYST_YEAR_ESTABLISH); ?>" class="form-control" name="Research_Analyst_Year_Establish">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" value="<?php echo e($data->RESEARCH_ANALYST_REVIEW); ?>" class="form-control" name="Research_Analyst_Review">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>