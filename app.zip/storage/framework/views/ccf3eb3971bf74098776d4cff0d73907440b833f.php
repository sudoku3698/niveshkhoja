<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-body">
                    <a href="<?php echo e(route('add_new_category')); ?>"><button class="btn btn-primary" >Add New Category</button></a>
                <table id="example2" class="table table-striped table-bordered table-hover">
                    <thead>
                     <tr>
                        <th>Category ID</th>

                        <th>Category Value</th>

                        <th>Service Tyoe</th>

                        <th>Created At</th>

                        <th>Edit</th>

                        <th>Delete</th>
                     </tr>

                    </thead>

                     <tbody>

                     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td><?php echo e($category->id); ?></td>

                            <td><?php echo e($category->category_value); ?></td>

                            <td><?php echo e($category->service_type); ?></td>

                            <td><?php echo e($category->created_at); ?></td>

                            <td><a href="<?php echo e(route('edit_category',['cat_id'=>$category->id])); ?>" class="btn btn-info btn-sm">Edit</a></td>

                            <td><a href="<?php echo e(route('delete_category',['cat_id'=>$category->id])); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm">Delete</a></td>
                        </tr> 

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>
                </div>
            </div>
        </div>    
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>