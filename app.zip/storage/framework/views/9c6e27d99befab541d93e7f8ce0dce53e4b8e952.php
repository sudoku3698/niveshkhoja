<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <div class="panel-body">
                <a class="small-header-action" href="">
                    <div class="clip-header">
                        <i class="fa fa-arrow-up"></i>
                    </div>
                </a>

                <div id="hbreadcrumb" class="pull-right m-t-lg">
                    <ol class="hbreadcrumb breadcrumb">
                        <li><a href="index.html">Dashboard</a></li>
                        <li>
                            <span>Tables</span>
                        </li>
                        <li class="active">
                            <span> Research  Analyst Details</span>
                        </li>
                    </ol>
                </div>
                <h2 class="font-light m-b-xs">
                   Research  Analyst Details
                   
                   <a href="<?php echo e(Route('downloadresearch_analystdetailsExcel',['type'=>'xls'])); ?>"><button class="btn btn-success">Download Excel xls</button></a>
        		   <a href="<?php echo e(Route('downloadresearch_analystdetailsExcel',['type'=>'xlsx'])); ?>"><button class="btn btn-success">Download Excel xlsx</button></a>
        		   <a href="<?php echo e(Route('downloadresearch_analystdetailsExcel',['type'=>'csv'])); ?>"><button class="btn btn-success">Download CSV</button></a>
        		    <form style="border: 1px solid #a1a1a1;margin-top: 15px;padding: 15px;" action="<?php echo e(Route('importresearch_analystdetailsExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
            			<div class="form-group">
            			    <?php echo e(csrf_field()); ?>

            			<input type="file" name="import_file" class="form-control"/>
            			</div>
            			<button class="btn btn-primary">Import File</button>
        		    </form>
                </h2>
                <!-- <small>Advanced interaction controls to any HTML table</small> -->
            </div> <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Deleted');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
                <div class="panel-heading">
                   
 


       
                <div class="panel-body">
                
                    <table id="example2" class="table table-striped table-bordered table-hover">
                    

                    <thead>
                     <tr>
                        <th>SUBCATEGORY</th>
                        <th>CONTACT</th>
                        <th>ADD</th>
                        <th>CONTACTPER</th>
                        <th>INSURER</th>
                        <th>REGNUM</th>
                        <th>CATEGORY</th>
                        <th>REGVALID_UPTO</th>
                        <!-- <th>RESEARCH_ANALYST_EMAIL_ID</th>
                        <th>RESEARCH_ANALYST_WEBSITE </th>
                       
                        <th>RESEARCH_ANALYST_SERVICES_OFFERED</th>
                        <th>RESEARCH_ANALYST_ABOUT</th>
                        <th>RESEARCH_ANALYST_YEAR_ESTABLISH</th>
                        <th>RESEARCH_ANALYST_REVIEW </th> -->
                        
                        <th>Edit</th>
                        <th>Delete</th>
                     </tr>
                    </thead>
                     <tbody>
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                   
                    <td><?php echo e($datas->RESEARCH_ANALYST_SUBCATEGORY); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_CONTACT); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_ADDRESS); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_CONTACT_PERSON); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_INSURER); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_REGISTRATION_NUMBER); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_CATEGORY); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_REGISTRATION_VALID_UPTO); ?></td>
                   <!--  <td><?php echo e($datas->RESEARCH_ANALYST_EMAIL_ID); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_WEBSITE); ?></td>
                   
                  
                    <td><?php echo e($datas->RESEARCH_ANALYST_SERVICES_OFFERED); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_ABOUT); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_YEAR_ESTABLISH); ?></td>
                    <td><?php echo e($datas->RESEARCH_ANALYST_REVIEW); ?></td> -->
                   <td><a href="editResearchAnalyst_fetch/<?php echo e($datas->id); ?>" class="btn btn-info btn-sm">Edit</a></td>
                    <td><a href="deleteResearchAnalyst/<?php echo e($datas->id); ?>" class="btn btn-danger btn-sm">Delete</a></td>   
                    
                         
                 </tr> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     






        </tbody>
                </table>
                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>