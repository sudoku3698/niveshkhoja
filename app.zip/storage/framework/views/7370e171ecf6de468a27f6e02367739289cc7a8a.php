<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                    Loan  
 


       
                <div class="panel-body">
                
               <form role="form"  method="post" action="http://localhost/bank_khoja/bank_khoja/updateLoan">
<input type="text" name="id" value="<?php echo e($data->id); ?>" hidden="">
                        <div class="form-group">
                        <label>Choose Loan-Category</label>
                        <select class="form-control" style="width: 100%" name="Loan_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="501" <?php echo e($data->LOAN_SUBCATEGORY == 501 ? "selected":""); ?>>Home Loan</option>
                            <option value="502" <?php echo e($data->LOAN_SUBCATEGORY == 502 ? "selected":""); ?>>Four Wheeler Loan</option>
                            <option value="503" <?php echo e($data->LOAN_SUBCATEGORY == 503 ? "selected":""); ?>>Personal Loan</option>
                            <option value="504" <?php echo e($data->LOAN_SUBCATEGORY == 504 ? "selected":""); ?>>Two Wheeler Loan</option>
                            <option value="505" <?php echo e($data->LOAN_SUBCATEGORY == 505 ? "selected":""); ?>>Education Loan</option>
                            <option value="506" <?php echo e($data->LOAN_SUBCATEGORY == 506 ? "selected":""); ?>>Business Loan</option>
                            <option value="507" <?php echo e($data->LOAN_SUBCATEGORY == 507 ? "selected":""); ?>>Gold Loan</option>
                            <option value="508" <?php echo e($data->LOAN_SUBCATEGORY == 508 ? "selected":""); ?>>Agriculture Loan</option>
                        </select>
                        </div>


                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Loan_Contact"  value="<?php echo e($data->LOAN_CONTACT); ?>">
                        </div>


                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" class="form-control" name="Loan_Address" value="<?php echo e($data->LOAN_ADDRESS); ?>">
                        </div>


                        <div class="form-group">
                        <label>Contact Person</label> 
                        <input type="text" placeholder="Enter Contact Person" class="form-control" name="Loan_Contact_Person" value="<?php echo e($data->LOAN_CONTACT_PERSON); ?>">
                        </div>

                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" class="form-control" name="Loan_Email_ID" value="<?php echo e($data->LOAN_EMAIL_ID); ?>">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website" class="form-control" name="Loan_Website" value="<?php echo e($data->LOAN_WEBSITE); ?>">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" class="form-control" name="Loan_Services_Offered" value="<?php echo e($data->LOAN_SERVICES_OFFERED); ?>">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" class="form-control" name="Loan_About" value="<?php echo e($data->LOAN_ABOUT); ?>">
                        </div>


                        <div class="form-group">
                        <label>Year Establish</label> 
                        <input type="text" placeholder="Enter Year Establish" class="form-control" name="Loan_Year_Establish" value="<?php echo e($data->LOAN_YEAR_ESTABLISH); ?>">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" class="form-control" name="Loan_Review" value="<?php echo e($data->LOAN_REVIEW); ?>">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>


                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>