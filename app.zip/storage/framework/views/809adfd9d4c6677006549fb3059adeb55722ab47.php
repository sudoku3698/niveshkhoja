<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                    cfacategory  
 


       
                <div class="panel-body">
                
                 <form role="form"  method="post" action="postmutual_fund">
            
            <div class="form-group">
            <label>Choose Loan-Category</label>
            <select class="form-control" style="width: 100%" name="Mutual_Fund_Distributor_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="601" <?php echo e((Input::old("Mutual_Fund_Distributor_Subcategory") == 601 ? "selected":"")); ?>>Mutual Fund Distributor</option>
                            <option value="602" <?php echo e((Input::old("Mutual_Fund_Distributor_Subcategory") == 602 ? "selected":"")); ?>>Mutual Fund Schemes</option>
              
            </select>
            </div>

            <div class="form-group">
            <label>Contact</label> 
            <input type="text" placeholder="Enter Contact" class="form-control" name="Mutual_Fund_Distributor_Contact" value="<?php echo e(old('Mutual_Fund_Distributor_Contact')); ?>">
            </div>

            <div class="form-group">
            <label>Address</label> 
            <input type="text" placeholder="Enter Address" class="form-control" name="Mutual_Fund_Distributor_Address" value="<?php echo e(old('Mutual_Fund_Distributor_Address')); ?>">
            </div>

            <div class="form-group">
            <label>Contact Person</label> 
            <input type="text" placeholder="Enter Contact Person" class="form-control" name="Mutual_Fund_Distributor_Contact_Person" value="<?php echo e(old('Mutual_Fund_Distributor_Contact_Person')); ?>">
            </div>

            <div class="form-group">
            <label>AMFI Registration Number(ARN)</label> 
            <input type="text" placeholder="Enter AMFI Registration Number" class="form-control" name="Mutual_Fund_Distributor_AMFI_Registration_Number" value="<?php echo e(old('Mutual_Fund_Distributor_AMFI_Registration_Number')); ?>">
            </div>

            <div class="form-group">
            <label>ARN Validity</label> 
            <input type="text" placeholder="Enter ARN Valid till" class="form-control" name="Mutual_Fund_Distributor_ARN_Validity" value="<?php echo e(old('Mutual_Fund_Distributor_ARN_Validity')); ?>">
            </div>

            <div class="form-group">
            <label>KYD</label> 
            <input type="text" placeholder="Enter KYD" class="form-control" name="Mutual_Fund_Distributor_KYD" value="<?php echo e(old('Mutual_Fund_Distributor_KYD')); ?>">
            </div>

            <div class="form-group">
            <label>EUIN</label> 
            <input type="text" placeholder="Enter EUIN" class="form-control" name="Mutual_Fund_Distributor_EUIN" value="<?php echo e(old('Mutual_Fund_Distributor_EUIN')); ?>">
            </div>

            <div class="form-group">
            <label>Email</label> 
            <input type="email" placeholder="Enter Email" class="form-control" name="Mutual_Fund_Distributor_Email_ID" value="<?php echo e(old('Mutual_Fund_Distributor_Email_ID')); ?>">
            </div>

            <div class="form-group">
            <label>Website</label> 
            <input type="text" placeholder="Enter Website" class="form-control" name="Mutual_Fund_Distributor_Website" value="<?php echo e(old('Mutual_Fund_Distributor_Website')); ?>">
            </div>


            <div class="form-group">
            <label>Services Offered</label> 
            <input type="text" placeholder="Enter Services Offered" class="form-control" name="Mutual_Fund_Distributor_Services_Offered" value="<?php echo e(old('Mutual_Fund_Distributor_Services_Offered')); ?>">
            </div>


            <div class="form-group">
            <label>About</label> 
            <input type="text" placeholder="Enter About Us" class="form-control" name="Mutual_Fund_Distributor_About" value="<?php echo e(old('Mutual_Fund_Distributor_About')); ?>">
            </div>


            <div class="form-group">
            <label>Year Established</label> 
            <input type="text" placeholder="Enter Year Established" class="form-control" name="Mutual_Fund_Distributor_Year_Establish" value="<?php echo e(old('Mutual_Fund_Distributor_Year_Establish')); ?>">
            </div>


            <div class="form-group">
            <label>Review</label> 
            <input type="text" placeholder="Enter Review" class="form-control" name="Mutual_Fund_Distributor_Review" value="<?php echo e(old('Mutual_Fund_Distributor_Review')); ?>">
            </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>