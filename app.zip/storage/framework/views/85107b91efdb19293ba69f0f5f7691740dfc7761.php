<?php $__env->startSection('content'); ?>
   <style>
     td, th {
      padding: 4px;
    } 
   </style>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="hpanel">
                    <div class="panel-heading">
                     <?php if(Session::has('success')): ?>
                     <div class="alert alert-success">
                       <strong>Success!</strong> <?php echo e(Session('success')); ?>

                     </div>
                     <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        
                        <form method="post" action="<?php echo e(Route('add_ad')); ?>" enctype="multipart/form-data">
                           <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                            <table>
                                <tr>
                                    <th><label>Service Type</label></th>
                                    <td>
                                        <div class="form-group">
                                            <select id="service_type" name="service_type" class="form-control" required>
            									<option value="" disabled selected>Select Service Type</option>
            									<?php $__currentLoopData = config('service_type.service_types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$service_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            									<option value="<?php echo e($key); ?>"><?php echo e($service_type); ?></option>
            									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        								    </select>
    								    </div>
    								</td>
                                </tr>
                                <tr>
                                    <th><label>Ad Page</label></th>
                                    <td><div class="form-group"><input type="file" name="ad_page" class="form-control" required></div></td>
                                </tr>
                                <tr>
                                    <th><label>Title</label></th>
                                    <td><div class="form-group"><input type="text" name="title" class="form-control" required></div></td>
                                </tr>
                                <tr>
                                    <th><label>Link</label></th>
                                    <td><div class="form-group"><input type="text" name="link" class="form-control" required></div></td>
                                </tr>
                                 <tr>
                                    <th><label>Min Weight</label></th>
                                    <td>
                                        <div class="form-group" ><select name="min" class="form-control" style="width: 100%">
                                            <?php for($i=1;$i<=100;$i++){ ?>
                                            <option value="<?=$i?>"><?=$i?></option>
                                            <?php }  ?>
                                        </select></div>
                                    </td>
                                </tr>
                                 <tr>
                                    <th><label>Max Weight</label></th>
                                    <td>
                                        <div class="form-group" ><select name="max" class="form-control" style="width: 100%">
                                        <?php for($i=1;$i<=100;$i++){ ?>
                                        <option value="<?=$i?>"><?=$i?></option>
                                        <?php }  ?>
                                    </select></div>
                                    </td>
                                </tr>
                                <tr>
                                    <th></th>
                                    <td>
                                        <input type="submit" value="Add">
                                    </select>
                                    </td>
                                </tr>
                            </table>
                         </form>
                        
                    </div>
                </div>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hpanel">
                <form method="post" action="<?php echo e(Route('delete_ad')); ?>">
                     <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="add_id" value="<?php echo $ad->id; ?>">
                    <div class="panel-heading"><?php echo e($ad->title); ?> ( <u><a href="<?php echo e($ad->link); ?>"><?php echo e($ad->link); ?></a></u> )</div>
                    <div class="panel-body">
                     
                      <input type="submit" value="delete" onclick="return confirm('Are You Sure?')">
                      <a href="<?php echo e(asset('public/ad_images/'.$ad->ad_page)); ?>" onclick="return !window.open(this.href, 'salary_slip', 'width=1200,height=600')" target="_blank"><u>image</u></a>
                        
                          Weight:- Min=<?php echo e($ad->min); ?> Max=<?php echo e($ad->max); ?>

                    </div>
                  </form>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>