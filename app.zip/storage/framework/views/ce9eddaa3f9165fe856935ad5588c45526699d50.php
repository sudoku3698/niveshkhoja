<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                    Broker Add  
 


       
                <div class="panel-body">
                
                   <form role="form"  method="post" action="<?php echo e(url('updatebrokersubbroker')); ?>">
<input type="text" name="id" value="<?php echo e($data->id); ?>" hidden="">
                        <div class="form-group">
                        <label>Choose Sub-Category</label>
                        <select class="form-control" style="width: 100%" name="Broker_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="201" <?php echo e($data->BROKER_SUBCATEGORY == 201 ? "selected":""); ?>>Demo1</option>
                            <option value="202" <?php echo e($data->BROKER_SUBCATEGORY == 202 ? "selected":""); ?>>Demo2</option>
                        </select>
                        </div>

                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact(Broker/Sub Broker)" class="form-control" name="Broker_Contact"  value="<?php echo e($data->BROKER_CONTACT); ?>">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" class="form-control" name="Broker_Address"   value="<?php echo e($data->BROKER_ADDRESS); ?>">
                        </div>

                        <div class="form-group">
                        <label>Contact Person</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Broker_Contact_Person"  value="<?php echo e($data->BROKER_CONTACT_PERSON); ?>">
                        </div>

                        <div class="form-group">
                        <label>Registration Number</label> 
                        <input type="text" placeholder="Enter Registration Number" class="form-control" name="Broker_Registration_Number"  value="<?php echo e($data->BROKER_REGISTRATION_NUMBER); ?>">
                        </div>

                        <div class="form-group">
                        <label>Stock Exchange</label> 
                        <input type="text" placeholder="Enter Stock Exchange" class="form-control" name="Broker_Stock_Exchange"  value="<?php echo e($data->BROKER_STOCK_EXCHANGE); ?>">
                        </div>

                        <div class="form-group">
                        <label>Category</label>  
                        <input type="text" placeholder="Enter Category" class="form-control" name="Broker_Category"  value="<?php echo e($data->BROKER_CATEGORY); ?>">
                        </div>

                        <div class="form-group">
                        <label>Recommending Broker Name</label> 
                        <input type="text" placeholder="Enter Recommending Broker Name" class="form-control" name="Broker_Recommending_Broker_Name"  value="<?php echo e($data->BROKER_RECOMMENDING_BROKER_NAME); ?>">
                        </div>

                        <div class="form-group">
                        <label>Recommending Broker Reg. Number</label> 
                        <input type="text" placeholder="Enter Recommending Broker Reg. Number" class="form-control" name="Broker_Recommending_Broker_Reg_Number"  value="<?php echo e($data->BROKER_RECOMMENDING_BROKER_REG_NUMBER); ?>">
                        </div>
                       
                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" class="form-control" name="Broker_Email_ID"  value="<?php echo e($data->BROKER_EMAIL_ID); ?>">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website" class="form-control" name="Broker_Website"  value="<?php echo e($data->BROKER_WEBSITE); ?>">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" class="form-control" name="Broker_Services_Offered"  value="<?php echo e($data->BROKER_SERVICES_OFFERED); ?>">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" class="form-control" name="Broker_About"  value="<?php echo e($data->BROKER_ABOUT); ?>">
                        </div>


                        <div class="form-group">
                        <label>Year Established</label> 
                        <input type="text" placeholder="Enter Year Established" class="form-control" name="Broker_Year_Establish"  value="<?php echo e($data->BROKER_YEAR_ESTABLISH); ?>">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" class="form-control" name="Broker_Review"  value="<?php echo e($data->BROKER_REVIEW); ?>">
                        </div>

                        <input type="hidden" name="Broker" value="broker_form">

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                        
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>