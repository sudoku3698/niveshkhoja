<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>


         <?php if(count($errors) > 0): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
                <div class="panel-heading">
                    Bank Details 
 


       
                <div class="panel-body">
                
                    <form role="form" id="form"  action="searchkeyword" method="post">

                        <div class="form-group">
                        <label>Choose Cities</label>
                        <select class="form-control" style="width: 100%" name="search_cities">
                            <option value="">Please  Select</option>
                            <?php $__currentLoopData = $Cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cit->city_id); ?>"><?php echo e($cit->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <option value="101" <?php echo e((Input::old("Bank_Category") == 101 ? "selected":"")); ?>>Cooperative Societies</option>
                            <option value="102" <?php echo e((Input::old("Bank_Category") == 102 ? "selected":"")); ?>>RNBC</option>
                            <option value="103" <?php echo e((Input::old("Bank_Category") == 103 ? "selected":"")); ?>>MFI</option>
                            <option value="104" <?php echo e((Input::old("Bank_Category") == 104 ? "selected":"")); ?>>NBFC</option> -->
                        </select>
                        </div>

                        

                        <div class="form-group">
                        <label>Search Keyword</label> 
                        <select class="form-control" style="width: 100%" name="search_keyword">
                            <option value="">Please  Select</option>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($datas->category_value); ?>"><?php echo e($datas->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <option value="101" <?php echo e((Input::old("Bank_Category") == 101 ? "selected":"")); ?>>Cooperative Societies</option>
                            <option value="102" <?php echo e((Input::old("Bank_Category") == 102 ? "selected":"")); ?>>RNBC</option>
                            <option value="103" <?php echo e((Input::old("Bank_Category") == 103 ? "selected":"")); ?>>MFI</option>
                            <option value="104" <?php echo e((Input::old("Bank_Category") == 104 ? "selected":"")); ?>>NBFC</option> -->
                        </select>
                       
                        </div>

                        
                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                        
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>