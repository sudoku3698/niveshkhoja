
<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>


         <?php if(count($errors) > 0): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
                <div class="panel-heading">
                    Bank Details 

       
                <div class="panel-body">
                
                    <form role="form" id="form"  action="<?php echo e(url('updatebankdetails')); ?>" method="post" enctype="multipart/form-data">
                      <input type="text" name="Bank_id"  value="<?php echo e($data->id); ?>" hidden="">
                        <div class="form-group">
                        <label>Choose Category</label>
                            <select class="form-control" style="width: 100%" name="Bank_Category">
                                <option value="">Please  Select</option>
                                <?php $__currentLoopData = $category_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_mast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category_mast->service_type=='bank_details'): ?>
                                <option value="<?php echo e($category_mast->id); ?>" <?php echo e($data->BANK_CATEGORY==$category_mast->id?"selected":""); ?>><?php echo e($category_mast->category_value); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                        <label>Choose City</label>
                        <select class="form-control" style="width: 100%" name="cities">
                            <option value="">Please  Select City</option>
                            <?php $__currentLoopData = $Cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->city_id); ?>" <?php echo e(($data->search_cities== $city->city_id ? "selected":"")); ?>><?php echo e($city->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>

                        <div class="form-group">
                        <img src="<?php echo e(asset('public/banners/'.$data->banner)); ?>" alt="<?php echo e($data->banner); ?>" height="300" width="300">
                        <label>Banner</label> 
                        <input type="file" class="form-control" name="banner" value="<?php echo e(old('banner')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Name</label> 
                        <input type="text" placeholder="Enter Bank Name" class="form-control" name="Bank_Name" value="<?php echo e($data->BANK_NAME); ?>">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" class="form-control" name="Bank_Address" value="<?php echo e($data->BANK_ADDRESS); ?>">
                        </div>

                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Bank_Contact" value="<?php echo e($data->BANK_CONTACT); ?>">
                        </div>

                        <div class="form-group">
                        <label>IFSC Code</label> 
                        <input type="text" placeholder="Enter IFSC Code" class="form-control" name="Bank_IFSC_Code" value="<?php echo e($data->BANK_IFSC_CODE); ?>">
                        </div>

                        <div class="form-group">
                        <label>Branch</label> 
                        <input type="text" placeholder="Enter Branch" class="form-control" name="Bank_Branch"  value="<?php echo e($data->BANK_BRANCH); ?>">
                        </div>

                        <div class="form-group">
                        <label>MICR Code</label> 
                        <input type="text" placeholder="Enter MICR Code" class="form-control" name="Bank_MICR_Code" value="<?php echo e($data->BANK_MICR_CODE); ?>">
                        </div>
                       
                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" class="form-control" name="Bank_Email_ID" value="<?php echo e($data->BANK_EMAIL_ID); ?>">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website" class="form-control" name="Bank_Website" value="<?php echo e($data->BANK_WEBSITE); ?>">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" class="form-control" name="Bank_Services_Offered" value="<?php echo e($data->BANK_SERVICES_OFFERED); ?>">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" class="form-control" name="Bank_About" value="<?php echo e($data->BANK_ABOUT); ?>">
                        </div>


                        <div class="form-group">
                        <label>Year Establish</label> 
                        <input type="text" placeholder="Enter Year Establish" class="form-control" name="Bank_Year_Establish" value="<?php echo e($data->BANK_YEAR_ESTABLISH); ?>">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input id="#datetimepicker" type="text" placeholder="Enter Review" class="form-control" name="Bank_Review" value="<?php echo e($data->BANK_REVIEW); ?>">
                        </div>

                        
                        <div class="form-group">
                        <label>Rank</label> 
                        <input  required type="number" placeholder="Enter Review" class="form-control" name="rank" value="<?php echo e($data->rank); ?>">
                        </div>

                        <div class="form-group">
                        <img src="<?php echo e(asset('public/advertisements/'.$data->advertisement)); ?>" alt="<?php echo e($data->advertisement); ?>" height="300" width="300">
                        <label>Advertisement</label> 
                        <input type="file" class="form-control" name="advertisement" value="<?php echo e(old('advertisement')); ?>">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                        
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>