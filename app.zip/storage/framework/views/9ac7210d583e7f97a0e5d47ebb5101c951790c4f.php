<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                   Investment Advisors
 


       
                <div class="panel-body">
          <form role="form"  method="post" action="<?php echo e(url('updatepostinvestment_advisors')); ?>">
<input type="text" name="id" value="<?php echo e($data->id); ?>" hidden="">
                        <div class="form-group">
                        <label>Choose Investment Advisors Category</label>
                        <select class="form-control" style="width: 100%" name="Investment_Advisors_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="801" <?php echo e($data->INVESTMENT_ADVISORS_SUBCATEGORY == 801 ? "selected":""); ?>>Gold/Silver</option>
                            <option value="802" <?php echo e($data->INVESTMENT_ADVISORS_SUBCATEGORY == 802 ? "selected":""); ?>>Antiques</option>
                            <option value="803" <?php echo e($data->INVESTMENT_ADVISORS_SUBCATEGORY == 803 ? "selected":""); ?>>Arts</option>
                        </select>
                        </div>

                        <div class="form-group">
                        <label>Name</label> 
                        <input type="text" placeholder="Enter Investment Advisors Name" class="form-control" name="Investment_Advisors_Name" value="<?php echo e($data->INVESTMENT_ADVISORS_NAME); ?>">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" class="form-control" name="Investment_Advisors_Address" value="<?php echo e($data->INVESTMENT_ADVISORS_ADDRESS); ?>"> 
                        </div>

                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Investment_Advisors_Contact" value="<?php echo e($data->INVESTMENT_ADVISORS_CONTACT); ?>">
                        </div>

                    
                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" class="form-control" name="Investment_Advisors_Email_ID" value="<?php echo e($data->INVESTMENT_ADVISORS_EMAIL_ID); ?>">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website" class="form-control" name="Investment_Advisors_Website" value="<?php echo e($data->INVESTMENT_ADVISORS_WEBSITE); ?>">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" class="form-control" name="Investment_Advisors_Services_Offered" value="<?php echo e($data->INVESTMENT_ADVISORS_SERVICES_OFFERED); ?>">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" class="form-control" name="Investment_Advisors_About" value="<?php echo e($data->INVESTMENT_ADVISORS_ABOUT); ?>">
                        </div>


                        <div class="form-group">
                        <label>Year Establish</label> 
                        <input type="text" placeholder="Enter Year Establish" class="form-control" name="Investment_Advisors_Year_Establish" value="<?php echo e($data->INVESTMENT_ADVISORS_YEAR_ESTABLISH); ?>">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" class="form-control" name="Investment_Advisors_Review" value="<?php echo e($data->INVESTMENT_ADVISORS_REVIEW); ?>">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>