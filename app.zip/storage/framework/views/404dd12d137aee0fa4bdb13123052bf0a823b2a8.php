<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                    Insurance  
 


       
                <div class="panel-body">
                
                  <form role="form"  method="post" action="postinsurance">

                        <div class="form-group">
                        <label>Choose Insurance-Category</label>
                        <select class="form-control" style="width: 100%" name="Insurance_Subcategory">
                            <option value="">Please  Select</option>
                            <option value="401" <?php echo e((Input::old("Insurance_Subcategory") == 401 ? "selected":"")); ?>>Health Insurance</option>
                            <option value="402" <?php echo e((Input::old("Insurance_Subcategory") == 402 ? "selected":"")); ?>>Travel Insurance</option>
                            <option value="403" <?php echo e((Input::old("Insurance_Subcategory") == 403 ? "selected":"")); ?>>Property Insurance</option>
                            <option value="404" <?php echo e((Input::old("Insurance_Subcategory") == 404 ? "selected":"")); ?>>Two Wheeler Insurance</option>
                            <option value="405" <?php echo e((Input::old("Insurance_Subcategory") == 405 ? "selected":"")); ?>>Four Wheeler Insurance</option>
                            <option value="406" <?php echo e((Input::old("Insurance_Subcategory") == 406 ? "selected":"")); ?>>Accident Insurance</option>
                            <option value="407" <?php echo e((Input::old("Insurance_Subcategory") == 407 ? "selected":"")); ?>>Home Insurance</option>
                            <option value="408" <?php echo e((Input::old("Insurance_Subcategory") == 408 ? "selected":"")); ?>>Rural Insurance</option>
                            <option value="409" <?php echo e((Input::old("Insurance_Subcategory") == 409 ? "selected":"")); ?>>Life Insurance</option>
                        </select>
                        </div>

                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Insurance_Contact" value="<?php echo e(old('Insurance_Contact')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" class="form-control" name="Insurance_Address" value="<?php echo e(old('Insurance_Address')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Contact Person</label> 
                        <input type="text" placeholder="Enter Contact" class="form-control" name="Insurance_Contact_Person" value="<?php echo e(old('Insurance_Contact_Person')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Insurer</label> 
                        <input type="text" placeholder="Enter Insurer Name" class="form-control" name="Insurance_Insurer" value="<?php echo e(old('Insurance_Insurer')); ?>">
                        </div>

                        <div class="form-group">
                        <label>License Number</label> 
                        <input type="text" placeholder="Enter License Number" class="form-control" name="Insurance_License_Number" value="<?php echo e(old('Insurance_License_Number')); ?>">
                        </div>

                        <div class="form-group">
                        <label>IRDS URN</label> 
                        <input type="text" placeholder="Enter IRDS URN" class="form-control" name="Insurance_Irds_URN" value="<?php echo e(old('Insurance_Irds_URN')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Agent ID</label> 
                        <input type="text" placeholder="Enter Agent ID" class="form-control" name="Insurance_Agent_ID" value="<?php echo e(old('Insurance_Agent_ID')); ?>">
                        </div>
                       
                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" class="form-control" name="Insurance_Email_ID" value="<?php echo e(old('Insurance_Email_ID')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website" class="form-control" name="Insurance_Website" value="<?php echo e(old('Insurance_Website')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" class="form-control" name="Insurance_Services_Offered" value="<?php echo e(old('Insurance_Services_Offered')); ?>">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" class="form-control" name="Insurance_About" value="<?php echo e(old('Insurance_About')); ?>">
                        </div>


                        <div class="form-group">
                        <label>Year Established</label> 
                        <input type="text" placeholder="Enter Year Established" class="form-control" name="Insurance_Year_Establish" value="<?php echo e(old('Insurance_Year_Establish')); ?>">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" class="form-control" name="Insurance_Review" value="<?php echo e(old('Insurance_Review')); ?>">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>