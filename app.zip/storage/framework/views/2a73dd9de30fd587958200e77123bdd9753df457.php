<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <div class="panel-body">
                <a class="small-header-action" href="">
                    <div class="clip-header">
                        <i class="fa fa-arrow-up"></i>
                    </div>
                </a>
                <?php if($message = Session::get('success')): ?>
            		<div class="alert alert-info alert-dismissible fade in" role="alert">
            	      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            	        <span aria-hidden="true">×</span>
            	      </button>
            	      <strong>Success!</strong> <?php echo e($message); ?>

            	    </div>
            	<?php endif; ?>
            	<?php echo Session::forget('success'); ?>

               
                <h2 class="font-light m-b-xs">
                    Bank Details
                     <a href="<?php echo e(Route('downloadbankdetailsExcel',['type'=>'xls'])); ?>"><button class="btn btn-success">Download Excel xls</button></a>
        		   <a href="<?php echo e(Route('downloadbankdetailsExcel',['type'=>'xlsx'])); ?>"><button class="btn btn-success">Download Excel xlsx</button></a>
        		   <a href="<?php echo e(Route('downloadbankdetailsExcel',['type'=>'csv'])); ?>"><button class="btn btn-success">Download CSV</button></a>
        		    <form style="border: 1px solid #a1a1a1;margin-top: 15px;padding: 15px;" action="<?php echo e(Route('importbankdetailsExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
            			<div class="form-group">
            			    <?php echo e(csrf_field()); ?>

            			<input type="file" name="import_file" class="form-control"/>
            			</div>
            			<button class="btn btn-primary">Import File</button>
        		    </form>
                </h2>
                
                <!-- <small>Advanced interaction controls to any HTML table</small> -->
            </div> <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Deleted');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
                <div class="panel-heading">
                   
 


       
                <div class="panel-body">
                  
                    <table id="example2" class="table table-striped table-bordered table-hover">
                    

                    <thead>
                     <tr>
                        <th>Bank_Cat</th>
                        <th>Bank_Name</th>
                        <th>Bank_Add</th>
                        <th>Bank_Cont</th>
                        <th>Bank_IFSC</th>
                        <th>Bank_Branch</th>
                        <th>Bank_MICR</th>
                        <th>Bank_Email</th>
                        <th>Bank_Web</th>
                    
                        <th>Edit</th>
                        <th>Delete</th>
                        
                     </tr>
                    </thead>
                     <tbody>
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                   
                    <td><?php echo e($datas->BANK_CATEGORY); ?></td>
                    <td><?php echo e($datas->BANK_NAME); ?></td>
                    <td><?php echo e($datas->BANK_ADDRESS); ?></td>
                    <td><?php echo e($datas->BANK_CONTACT); ?></td>
                    <td><?php echo e($datas->BANK_IFSC_CODE); ?></td>
                    <td><?php echo e($datas->BANK_BRANCH); ?></td>
                    <td><?php echo e($datas->BANK_MICR_CODE); ?></td>
                    <td><?php echo e($datas->BANK_EMAIL_ID); ?></td>
                    <td><?php echo e($datas->BANK_WEBSITE); ?></td>
              
                   
                      <td><a href="editbankdetails/<?php echo e($datas->id); ?>" class="btn btn-info btn-sm">Edit</a></td>
                    <td><a href="deletebank/<?php echo e($datas->id); ?>" class="btn btn-danger btn-sm">Delete</a></td>    
                 </tr> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     






        </tbody>
                </table>
                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>