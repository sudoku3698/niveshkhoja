<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="hpanel">
                <div class="panel-body">
                <?php if(Session('success')): ?>
                    <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.success('Succesfully Saved');
                    });
                    </script>


                    <div class="alert alert-success">

                    <?php echo e(Session('success')); ?>


                    </div>

                <?php endif; ?>
                <?php if(Session('error')): ?>
                    <script type="text/javascript">
                            $(document).ready(function () {

                                toastr.error('Something Went Wrong, Please try Again.');
                            });
                    </script>
                    <div class="alert alert-danger">
                    <?php echo e(Session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                <script type="text/javascript">
                        $(document).ready(function () {

                            toastr.error('Something Went Wrong, Please try Again.');
                        });
                </script>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form role="form"  method="post" action="<?php echo e(route('update_category')); ?>">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="cat_id" value="<?php echo e($category->id); ?>">
                <div class="form-group">
                        <label>Choose Service</label>
                        <select class="form-control" style="width: 100%" name="service_type">
                            <option value="">Please Select Service</option>
                            <?php $__currentLoopData = config('service_type.service_types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_type=>$service_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service_type); ?>" <?php echo e(($service_type == $category->service_type ? "selected":"")); ?>><?php echo e($service_value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                           
                        <div class="form-group">
                        <label>Category</label> 
                        <input type="text" placeholder="Enter Category" class="form-control" name="category_value" value="<?php echo e($category->category_value); ?>">
                        </div>

                        
                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Update</strong></button>
                        </div>
                </form>
                </div>
            </div>
        </div>    
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>