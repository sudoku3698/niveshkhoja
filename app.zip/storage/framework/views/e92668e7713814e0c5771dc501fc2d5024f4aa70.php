<?php $__env->startSection('content'); ?>
<div class="content">

<div class="row">
<div class="col-lg-12">
 <div class="hpanel">

               <?php if(Session('success')): ?>
               <script type="text/javascript">
                $(document).ready(function () {

                    toastr.success('Succesfully Saved');
                });
                </script>


         <div class="alert alert-success">

         <?php echo e(Session('success')); ?>


         </div>

         <?php endif; ?>
           <?php if(Session('error')): ?>
         <script type="text/javascript">
                $(document).ready(function () {

                    toastr.error('Something Went Wrong, Please try Again.');
                });
                </script>
        

         <div class="alert alert-danger">

         <?php echo e(Session('error')); ?>


         </div>

         <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <script type="text/javascript">
                    $(document).ready(function () {

                        toastr.error('Something Went Wrong, Please try Again.');
                    });
            </script>
            
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            
                <div class="panel-heading">
                   Research Analyst
 


       
                <div class="panel-body">
        <form role="form"  method="post" action="postresearch_analyst">

                        <div class="form-group">
                        <label>Choose Research Analyst Category</label>
                        <select class="form-control" style="width: 100%" name="Research_Analyst_Subcategory">
                            <option value="">Please  Select</option>
                            <?php $__currentLoopData = $category_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_mast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category_mast->service_type=='research_analyst_details'): ?>
                                <option value="<?php echo e($category_mast->id); ?>" <?php echo e(Input::old("Research_Analyst_Subcategory")==$category_mast->id?"selected":""); ?>><?php echo e($category_mast->category_value); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        <div class="form-group">
                        <label>Choose City</label>
                        <select class="form-control" style="width: 100%" name="cities">
                            <option value="">Please  Select City</option>
                            <?php $__currentLoopData = $Cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->city_id); ?>" <?php echo e((Input::old("cities") == $city->city_id? "selected":"")); ?>><?php echo e($city->city_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>

                        <div class="form-group">
                        <label>Banner</label> 
                        <input type="file" class="form-control" name="banner" value="<?php echo e(old('banner')); ?>">
                        </div>
                        
                        <div class="form-group">
                        <label>Contact</label> 
                        <input type="text" placeholder="Enter Contact"  value="<?php echo e(old('Research_Analyst_Contact')); ?>" class="form-control" name="Research_Analyst_Contact">
                        </div>

                        <div class="form-group">
                        <label>Address</label> 
                        <input type="text" placeholder="Enter Address" value="<?php echo e(old('Research_Analyst_Address')); ?>" class="form-control" name="Research_Analyst_Address">
                        </div>

                        <div class="form-group">
                        <label>Contact Person</label> 
                        <input type="text" placeholder="Enter Contact Person"  value="<?php echo e(old('Research_Analyst_Contact_Person')); ?>" class="form-control" name="Research_Analyst_Contact_Person">
                        </div>

                        <div class="form-group">
                        <label>Insurer</label> 
                        <input type="text" placeholder="Enter Insurer"  value="<?php echo e(old('Research_Analyst_Insurer')); ?>" class="form-control" name="Research_Analyst_Insurer">
                        </div>

                        <div class="form-group">
                        <label>Registration Number</label> 
                        <input type="text" placeholder="Enter Registration Number" value="<?php echo e(old('Research_Analyst_Registration_Number')); ?>" class="form-control" name="Research_Analyst_Registration_Number">
                        </div>

                        <div class="form-group">
                        <label>Category</label> 
                        <input type="text" placeholder="Enter Category" value="<?php echo e(old('Research_Analyst_Category')); ?>" class="form-control" name="Research_Analyst_Category">
                        </div>


                        <div class="form-group">
                        <label>Registration Valid Upto</label> 
                        <input type="text" placeholder="Enter Registration Valid Upto" value="<?php echo e(old('Research_Analyst_Registration_Valid_Upto')); ?>" class="form-control" name="Research_Analyst_Registration_Valid_Upto">
                        </div>

                        <div class="form-group">
                        <label>Email</label> 
                        <input type="email" placeholder="Enter Email" value="<?php echo e(old('Research_Analyst_Email_ID')); ?>" class="form-control" name="Research_Analyst_Email_ID">
                        </div>

                        <div class="form-group">
                        <label>Website</label> 
                        <input type="text" placeholder="Enter Website"  value="<?php echo e(old('Research_Analyst_Website')); ?>" class="form-control" name="Research_Analyst_Website">
                        </div>


                        <div class="form-group">
                        <label>Services Offered</label> 
                        <input type="text" placeholder="Enter Services Offered" value="<?php echo e(old('Research_Analyst_Services_Offered')); ?>" class="form-control" name="Research_Analyst_Services_Offered">
                        </div>


                        <div class="form-group">
                        <label>About</label> 
                        <input type="text" placeholder="Enter About Us" value="<?php echo e(old('Research_Analyst_About')); ?>"  class="form-control" name="Research_Analyst_About">
                        </div>


                        <div class="form-group">
                        <label>Year Established</label> 
                        <input type="text" placeholder="Enter Year Established" value="<?php echo e(old('Research_Analyst_Year_Establish')); ?>" class="form-control" name="Research_Analyst_Year_Establish">
                        </div>


                        <div class="form-group">
                        <label>Review</label> 
                        <input type="text" placeholder="Enter Review" value="<?php echo e(old('Research_Analyst_Review')); ?>" class="form-control" name="Research_Analyst_Review">
                        </div>

                        <div class="form-group">
                        <label>Rank</label> 
                        <input  required type="number" placeholder="Enter Rank" class="form-control" name="rank" value="<?php echo e(old('rank')); ?>">
                        </div>

                        <div class="form-group">
                        <label>Advertisement</label> 
                        <input type="file" class="form-control" name="advertisement" value="<?php echo e(old('advertisement')); ?>">
                        </div>

                        <div>
                            <button class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Submit</strong></button>
                        </div>
                    </form>

                </div>
            </div>



</div>
</div>
</div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>